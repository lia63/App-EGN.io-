<?php

$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='';
$dbDatabase ='io';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);

?>