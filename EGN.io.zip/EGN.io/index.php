<?php include "layouts/header.php"; ?>

<body style="background-image: url(fondo9.jpg);
background-position:center;
background-repeat:no-repeat;
background-size:cover;
background-attachment:fixed">

<div class="container">

<center><h2 style="color:black; margin-top:18%">EGN.io.</h2></center>
<center><h2 style="color:black; margin-top:1%">🧠"Conectamos ideas, un mensaje a la vez.📨 Rápido, Ligero y Directo"</h2></center>
<center><h2 style="color:black; margin-top:0%">📱¿Listo para conversar?</h2></center>
<center><a href="https://www.EGN.io.com/"><img src="logo.png" width="290" height="240"></a></center>
</div>

</body>
</html>
