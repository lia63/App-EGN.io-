<?php 
	session_start();
	if(isset($_SESSION['name']))
	{
		include "layouts/header2.php"; 
		include "config.php"; 
		
		$sql="SELECT * FROM `chat`";

		$query = mysqli_query($conn,$sql);
?>
<style>
	body{
    background-image: url('fondo3.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-attachment: fixed;
  }
  h2{
color:purple;
  }
  label{
color:purple;
  }
  span{
	  color:#673ab7;
	  font-weight:bold;
  }
  .container {
    margin-top: 3%;
    width: 60%;
    background-color: #26262b9e;
    padding-right:10%;
    padding-left:10%;
	background-image: url('fondo3.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
	border-radius: 10px;
  }
  .btn-primary {
    background-color: #b73ab5ff;
	}
	.display-chat{
		height:300px;
		background-color:#d69de0;
		margin-bottom:4%;
		overflow:auto;
		padding:15px;
	}
	.message{
		background-color: #c616e469;
		color: white;
		border-radius: 5px;
		padding: 5px;
		margin-bottom: 3%;
	}
  </style>

<div class="container">
  <center><h2>¡Bienvenid@ a tu espacio de conversación!💬✨ <span style="color:#dd7ff3;"><?php echo $_SESSION['name']; ?> !</span></h2>
  <br><br>
	<label>Clic abajo para ingresar al chat</label><br>
	<br><br>
	<a href="chatpage.php" class="btn btn-primary">Abre el chat</a>
  
</div>

</body>
</html>
<?php
	}
	else
	{
		header('location:index.php');
	}
?>